<?php
namespace App\FurnitureFetchApi\DwellApi;
use App\FurnitureFetchApi\WooProductProperties;
class FilterFetchedProduct extends WooProductProperties{
    public function set_product_item($product){
        self::$product = $product ?? null;
    }
    public function set_product_name(){
        return self::$product['title'] ?? null;
    }

    public function set_product_sku(){
        return self::$product['sku'] ?? null;
    }

    public function set_product_id(){
        return self::$product['id'] ?? null;
    }

    public function set_stock_status(){
        return self::$product['available'] ?? null;
    }

    public function set_product_price(){
        return self::$product['compare_at_price'] ?? null;
    }

    public function set_regular_price(){
        return self::$product['price']?? null;
    }

    public function set_product_thumbnail(){
        $image['url']       =  self::$product['featured_image']['src'] ?? null;
        $image['label']     =  self::$product['featured_image']['alt'] ?? null;
        if($image['label']  == null){
            $image['url']   =  self::$product['featured_image']['src'] ?? null;
            $image['label'] =  self::$product['featured_image']['alts'] ?? null;
        }
        return $image;
    }

    public function set_product_currency(){
        return self::$product[0]['price']['regularPrice']['amount']['currency'] ?? null;
    }

    public function set_product_description(){
        return self::$product['description'] ?? null;
    }

    public function set_product_short_description(){
        return self::$product['product_info'] ?? null;
    }

    public function set_product_categories(){
        // if tags is empty
        if(!isset(self::$product['tags']))
           return null;

        // if tags found foreach it
        foreach(self::$product['tags'] as $category):
            $tags[] = [
                'name'    => $category,
                'url_key' => strtolower(str_replace(' ','-',$category))
            ];
        endforeach;
        self::$product['tags'] = $tags ?? null;
        return self::$product['tags'];
    }

    public function set_product_variation(){
        return self::$product['variants'] ?? null;
    }

    public function set_product_permalink(){
        return self::$product['handle'] ?? null;
    }

    public function set_product_gallery(){
        return self::$product[0]['media_gallery_entries'] ?? null;
    }

    public function set_product_slug(){
        return self::$product['handle'] ?? null;
    }

    public function set_related_products(){
        return self::$product['collectionIds'] ?? null;
    }

    public function set_attributes(){
        $type = [];

        // if types is Not empty
        if(isset(self::$product['type'])){

            // if type is loop type if array
            if(is_array(self::$product['type'])){
                foreach(self::$product['type'] as $key => $value){
                    $type[] = [
                        'attribute_label' => $key,
                        'attribute_value' => $value,
                        'attribute_type'  => 'select',
                        'attribute_code'  => strtolower(str_replace(' ','-',$key)),
                        'attribute_options'=> []
                    ];
                }
            }

            // if types is not array
            elseif(!is_array(self::$product['type'])){
                $type[] = [
                    'attribute_label' => self::$product['type'],
                    'attribute_value' => self::$product['type'],
                    'attribute_type'  => 'select',
                    'attribute_code'  => strtolower(str_replace(' ','-',self::$product['type'])),
                    'attribute_options'=> []
                ];
            }
        }

        // add options in attibute product
        foreach(self::$product as $key => $value){
            if(preg_match('/option[0-9]+/',$key)){
                $type[] = [
                    'attribute_label'  => $key,
                    'attribute_value'  => $value,
                    'attribute_type'   => 'select',
                    'attribute_code'   => strtolower(str_replace(' ','-',$key)),
                    'attribute_options'=> []
                ];
            }
        }

        return $type ?: null;
    }

    public function set_product_quantity(){
        return self::$product['quantity'] ?? null;
    }

    public function set_configurable_options(){
        foreach(self::$product as $key => $value){
            if(preg_match('/option[0-9]+/',$key)){
                self::$product['configurable_options'][] = [
                    'attribute_label'  => $key,
                    'attribute_value'  => $value,
                    'attribute_type'   => 'select',
                    'attribute_code'   => strtolower(str_replace(' ','-',$key))
                ];
            }
        }
        return self::$product['configurable_options'] ?? null;
    }

}


