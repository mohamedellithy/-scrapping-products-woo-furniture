<?php
namespace App\FurnitureFetchApi\DwellApi;
use App\FurnitureFetchApi\HandleFurnitureRequest;
use Symfony\Component\DomCrawler\Crawler;
use App\FurnitureFetchApi\DwellApi\FilterFetchedProduct;
use App\FurnitureFetchApi\DwellApi\InsertParentProduct;
//use App\FurnitureFetchApi\DwellApi\InsertAttributes;
class FetchSingleProduct extends HandleFurnitureRequest {
    public $endpoint = "https://danubehome.com/ae/en/graphql?hash=3576528246";
    protected $slugs;
    public function __construct(FetchProducts $products){
        set_time_limit(2000);
        // here fetch data
        $this->slugs  = $products->get_slugs();

        // fetch data from single product
        if(method_exists($this,'start_fetch_data')){

            // here start fetch data
            $this->start_fetch_data();
        }
    }

    public function start_fetch_data(){
        $results = [];

        // fetch data from single product
        if(method_exists($this,'FetchSingleDataProduct')){

            // foreach all slugs
            foreach($this->slugs as $slug){

                //$slug = 'pale-button-back-studded-sofa';

                // access endpoint
                $this->endpoint = "https://dwellstores.ae/collections/furniture/products/".$slug;

                // start fetch data in single product
                $this->FetchSingleDataProduct();

                // start fetch some data from crawler documents
                $crawler = new Crawler($this->results['products']);

                // get product json from html script [id = vtls-product-data]
                $json_data = $crawler->filter('script#vtls-product-data')->text();

                // handle and fixes some errors from return results
                $filter = str_replace("var vitals_product_data=",'',$json_data);
                $filter = str_replace(";",'',$filter);
                $filter = str_replace(", }",'}',$filter);
                $filter = str_replace(", ]",']',$filter);
                $filter = str_replace(",}",'}',$filter);
                $filter = str_replace(",]",']',$filter);

                // convert crawler to json format
                $filter = json_decode($filter,true);

                // get on product info by details from crawler
                $filter['product_info'] = $crawler->filter('div.om-description')->html();

                // start filter data fetched from single product
                $product_filtered = new FilterFetchedProduct($filter);

                // try to insert filtered data
                $insert_new_item  = new InsertParentProduct($product_filtered);

                $this->results    = $insert_new_item; // $product_filtered; // $insert_new_item->result;
                break;
            }

            //.$this->results = $results;
        }
    }

    public function FetchSingleDataProduct(){
        return $this->resolve_api($json= false);
    }

}
